#ifndef SERVER_STORE_H
#define SERVER_STORE_H


class server_store
{
public:
    server_store();
    void run();
};

#endif // SERVER_STORE_H
