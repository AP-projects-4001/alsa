#ifndef GLOBAL_CHENGE_INFO_H
#define GLOBAL_CHENGE_INFO_H


class global_chenge_info
{
protected:
    virtual void on_buttonBox_accepted() = 0;
};

#endif // GLOBAL_CHENGE_INFO_H
