#include "global_registor.h"

global_registor::global_registor()
{
    money_ =   "1000000";
}
