# alsa
The "Store" project of "alsa" group




The online store project using qt (c++ form) along with the service of sending goods using the one hot encoding algorithm in Python, this project has the ability to login using a password and facial recognition. (read product details)
This project has the ability to add a product, edit it, delete a product, inform about the latest market prices, and view recent purchases for the seller.
It also has the ability to view details in two audio or visual ways, and you can increase the number of items in the shopping cart and even delete them in two ways.
delivered in person or by mail, and also has the ability to report unauthorized goods for the buyer.
And it has other capabilities for admin and...